#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QLabel>
#include <QComboBox>
#include <QTabWidget>
#include <QTableWidget>
#include <QPushButton>
#include <QCheckBox>
#include <QImage>
#include <QMap>
#include <QVector>
#include <QString>
#include <QRectF>
#include <QUdpSocket>
#include <cstdint>
#include <QLibrary> // For dynamic DLL loading

// Forward declarations
class CameraManager;
class QGridLayout;
class QMenu;
class QAction;
class QActionGroup;
class ComputeBenchmarkDialog;
class QScreen;
class QSpinBox;
class QDoubleSpinBox;
class QTimer;
class QWidget;
class QStackedWidget;
class QScrollArea;
class QPlainTextEdit;
class TargetGridWidget;
class PatternPresetsWidget;
class PythonCodeEditor;
class PythonTrapScriptEngine;
namespace GSAlgorithm {
struct GSConfig;
}

// --- DLL Function Pointers (Bypasses the need for LabVIEW's extcode.h) ---
typedef void (__stdcall *Window_Settings_Func)(int32_t MonitorNumber, int32_t WindowNumber015, int32_t XPixelShift, int32_t YPixelShift);
typedef void (__stdcall *Window_Array_to_Display_Func)(uint8_t* _1DArrayIn, int32_t X_pixel_in, int32_t Y_pixel_in, int32_t WindowNumber015, int32_t targetDataSize);
typedef void (__stdcall *Window_Term_Func)(int32_t WindowNumber015);

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void openSettingsDialog();
    void openHologramGenerator();
    void openBenchmarkDialog();
    void openSourceIntensityDialog();
    void onSourceIntensityApplied(const QVector<float> &intensityMap, int width, int height, const QString &presetName, double beamWaistPx, const QImage &previewImage);
    void onTabChanged(int index);
    void toggleTheme();
    void onRecordingTimeUpdated(const QString &timeString);
    void onFPSUpdated(const QString &fpsString);
    void savePhaseMask();
    void updateCameraFeed(const QImage &img);
    void onCameraPreviewMonitorChanged(int index);
    void onCameraPreviewToggled(bool checked);
    void onScreenTopologyChanged();
    void onCameraZoomRoiChanged(const QRectF &roiNormalized, bool enabled);

    // Algorithm slots
    void onAlgorithmSelectionChanged(int index);
    void onGenerateGsMaskClicked();
    void onGsAutoRunTimeout();
    void onSendToSlmRequested();
    void showAboutDialog();

    // Image tab slots
    void loadTargetImage();
    void clearTargetImage();

    // SLM Slots
    void receiveHologram(const QImage &mask);
    void sendHologramToSLM(const QImage &mask);
    void loadPhasePattern();
    void loadCorrectionFile();
    void clearCorrectionMask();
    void sendToSLM();
    void clearSLM();
    void refreshMonitorSelectionMenu();
    void onMonitorActionTriggered(QAction *action);

    // Grid Widget Slots
    void onGridPointAdded(int pointId, QPointF physicalCoords);
    void onGridPointMoved(int pointId, QPointF newPhysicalCoords);
    void onGridPointRemoved(int pointId);
    void onGridPointSelected(int pointId);
    void onGridPointDeselected();
    void onTrapTableItemChanged(QTableWidgetItem *item);
    void onPatternGenerated(const QVector<QPointF> &points, const QString &summary, const QString &details);
    void onAnimationPresetChanged(int index);
    void onGenerateAnimationSequenceClicked();
    void onPlayAnimationClicked();
    void onStopAnimationClicked();
    void onResetAnimationClicked();
    void onAnimationTimerTimeout();
    void onGeneratePythonSequenceClicked();
    void onPlayPythonSequenceClicked();
    void onStopPythonSequenceClicked();
    void onResetPythonSequenceClicked();
    void onPythonTrapSelectionChanged(int index);
    void onSavePythonScriptClicked();
    void onLoadPythonScriptClicked();

protected:
    bool eventFilter(QObject *watched, QEvent *event) override;

private:
    enum SlmOutputMode {
        DllOutputMode = 0,
        DirectScreenOutputMode = 1
    };

    enum class GsRunTrigger {
        ManualButton = 0,
        AutoRunTimer = 1,
        SendToSlmPreRun = 2
    };

    enum class SequenceSource {
        AnimationPreset = 0,
        PythonScript = 1
    };

    // Grid enlargement/minimize
    bool gridEnlarged = false;
    QWidget *gridTitleBar = nullptr;
    QLabel *gridTitleLabel = nullptr;
    QPushButton *gridMaxMinBtn = nullptr;
    QWidget *controlsWidget = nullptr;
    QGridLayout *mainLayout = nullptr;

    // Control section wrappers for hiding/showing
    QWidget *toolsRow = nullptr;
    QWidget *controlsRow = nullptr;

    void setupUI();
    void createMenus();
    void createMonitors(QGridLayout *layout);
    void createControls(QGridLayout *layout);
    void setupConnections();
    void applyTheme(bool dark);
    void toggleGridEnlarged();
    void replaceGridWithPoints(const QVector<QPointF> &points);

    void updatePhasePreview();
    QImage composeFullResolutionMask(bool applyCorrection = true) const;
    QString configPath() const;
    bool isSelectedMonitorAvailable() const;
    QScreen *selectedScreen() const;
    void persistSelectedMonitor();
    bool isSelectedCameraPreviewMonitorAvailable() const;
    QScreen *selectedCameraPreviewScreen() const;
    void persistSelectedCameraPreviewMonitor();
    void persistCorrectionPath(const QString &path);
    void ensureDirectOutputWindow();
    void displayDirectOutput(const QImage &finalMask);
    void clearDirectOutput();
    QImage buildCameraDisplayImage(const QImage &img, bool includeTargetOverlay) const;
    QImage applyCameraZoomToDisplayImage(const QImage &img) const;
    QRect cameraZoomRectForSize(const QSize &size) const;
    QRectF normalizedCameraZoomRoiForSize(const QSize &size, const QRectF &roi) const;
    QRect cameraFeedDrawRectForImage(const QSize &imageSize) const;
    QRect previewDrawRectForImage(const QLabel *label, const QSize &imageSize) const;
    QRectF normalizedSelectionFromPoints(const QPoint &start, const QPoint &end, const QRect &drawRect) const;
    void updateCameraFeedLabel(const QImage &displayImg);
    void updatePreviewLabelImage(QLabel *label, const QImage &displayImg, bool showZoomOverlay);
    void publishXpSenderOverlay();
    void clearXpSenderOverlay();
    void refreshCameraPreviewMonitorOptions();
    void updateCameraPreviewButtonState();
    void updateCameraPreviewButtonText();
    void ensureCameraPreviewWindow();
    void updateExternalCameraPreview();
    void clearCameraPreviewOutput();
    void handleCameraFeedStopped();
    void updateCameraPixelReadout(const QPoint &labelPos, bool validHover, const QLabel *sourceLabel = nullptr);
    void updateGridHoverReadout(const QPoint &viewportPos, bool validHover);
    void tryAutoApplySavedCorrection();
    void applyCameraZoomState(const QRectF &roiNormalized, bool enabled, bool recordHistory);
    void resetCameraZoom();
    void undoCameraZoomStep();

    void updateAlgorithmSettingsUi();
    void scheduleGsAutoRun();
    void autoSendToSlmIfEnabled();
    bool generateAlgorithmMask(bool showWarnings, GsRunTrigger trigger);
    bool generateGsMaskFromLoadedImage(bool showWarnings,
                                       GsRunTrigger trigger,
                                       const QVector<float> &sourceAmplitude,
                                       bool usingDefaultSource);
    QVector<float> defaultGsSourceAmplitude() const;
    bool isGerchbergSaxtonSelected() const;
    bool isWeightedGsSelected() const;
    bool isRandomMaskEncodingSelected() const;
    bool isAutoMaskGenerationAlgorithmSelected() const;
    bool runGsForTargetPoints(const QVector<QPointF> &points, int iterationsOverride, QImage &outMask, QString *errorOut = nullptr);
    GSAlgorithm::GSConfig buildGsConfig(int iterationsOverride = -1) const;
    void updateAnimationControlsEnabledState();
    void updateAnimationPreviewLabels(const QVector<QPointF> &points);
    QImage buildAnimationPreviewImage(const QVector<QPointF> &points, bool cameraStyle, int highlightIndexOneBased = -1) const;
    bool buildAnimationSequenceFromUi(bool showWarnings);
    bool buildPythonSequenceFromUi(bool showWarnings);
    bool precomputeAnimationMasks(bool showWarnings);
    void clearAnimationSequenceState(bool clearPreviews);
    void populatePythonTrapSelector();
    void applyTrapHighlightForCurrentFrame(const QVector<QPointF> &points);
    bool currentSequenceRealtime() const;
    int animationTimerIntervalMs() const;
    int currentSequenceFps() const;
    QString defaultPythonScriptTemplate() const;
    bool shouldHandleGlobalPointShortcut() const;
    void moveSelectedPointByKeyboard(int deltaX, int deltaY);
    void removeSelectedPointByKeyboard();
    void removeLastCreatedPointByKeyboard();
    void restoreSelectedPointSelection();
    QList<QTableWidget *> pointTables() const;
    void clearPointTables();
    void addPointRowToTables(int pointId, const QPointF &pixelCoords);
    void updatePointRowInTables(int pointId, const QPointF &pixelCoords);
    void removePointRowFromTables(int pointId);
    void selectPointRowInTables(int pointId);
    void clearPointTableSelections();

    // UI Pointers
    TargetGridWidget *targetGridWidget;
    QTabWidget *targetModeTabs;
    PatternPresetsWidget *patternPresetsWidget = nullptr;
    QTableWidget *trapTable;
    QTableWidget *cameraTrapTable = nullptr;
    QLabel *phaseMaskLabel;
    QLabel *gridHoverLabel = nullptr;
    QLabel *resolutionLabel;
    QLabel *fpsLabel;
    QCheckBox *previewCorrectionCb;
    QPushButton *saveMaskBtn;
    QPushButton *addPointsBtn;
    QPushButton *clearAllPointsBtn;
    QPushButton *cameraTabAddPointsBtn = nullptr;
    QPushButton *cameraTabClearAllPointsBtn = nullptr;
    QWidget *animationTab = nullptr;
    QScrollArea *animationScrollArea = nullptr;
    QWidget *animationContentWidget = nullptr;
    QComboBox *animationPresetCombo = nullptr;
    QStackedWidget *animationParamsStack = nullptr;
    QSpinBox *animationFpsSpin = nullptr;
    QSpinBox *animationFrameCountSpin = nullptr;
    QSpinBox *animationParticlesSpin = nullptr;
    QCheckBox *animationRealtimeCheck = nullptr;
    QDoubleSpinBox *animCircleRadiusFromSpin = nullptr;
    QDoubleSpinBox *animCircleRadiusToSpin = nullptr;
    QDoubleSpinBox *animTriangleScaleFromSpin = nullptr;
    QDoubleSpinBox *animTriangleScaleToSpin = nullptr;
    QDoubleSpinBox *animTriangleRotationFromSpin = nullptr;
    QDoubleSpinBox *animTriangleRotationToSpin = nullptr;
    QLabel *animationIntensityPreviewLabel = nullptr;
    QLabel *animationCameraPreviewLabel = nullptr;
    QPushButton *animationGenerateBtn = nullptr;
    QPushButton *animationPlaySendBtn = nullptr;
    QPushButton *animationStopBtn = nullptr;
    QPushButton *animationResetBtn = nullptr;
    QWidget *pythonTab = nullptr;
    PythonCodeEditor *pythonCodeEditor = nullptr;
    QSpinBox *pythonFpsSpin = nullptr;
    QSpinBox *pythonFrameCountSpin = nullptr;
    QSpinBox *pythonMaxPointsSpin = nullptr;
    QCheckBox *pythonRealtimeCheck = nullptr;
    QComboBox *pythonTrapSelectorCombo = nullptr;
    QLabel *pythonStatusLabel = nullptr;
    QLabel *pythonIntensityPreviewLabel = nullptr;
    QLabel *pythonCameraPreviewLabel = nullptr;
    QPushButton *pythonGenerateBtn = nullptr;
    QPushButton *pythonPlaySendBtn = nullptr;
    QPushButton *pythonStopBtn = nullptr;
    QPushButton *pythonResetBtn = nullptr;
    QPushButton *pythonSaveScriptBtn = nullptr;
    QPushButton *pythonLoadScriptBtn = nullptr;

    // Algorithm controls
    QComboBox *algorithmCombo = nullptr;
    QLabel *iterationsLabel = nullptr;
    QSpinBox *iterationsSpin = nullptr;
    QLabel *relaxationLabel = nullptr;
    QDoubleSpinBox *relaxationSpin = nullptr;
    QPushButton *generateGsBtn = nullptr;

    // Image tab controls/state
    QPushButton *loadTargetImageBtn;
    QPushButton *clearTargetImageBtn;
    QLabel *targetImageInfoLabel;
    QImage loadedTargetImageOriginal;
    QImage loadedTargetImageGray;

    // Source intensity state (SLM-sized array)
    QVector<float> sourceIntensityMap;
    QImage sourceIntensityPreview;
    QString sourcePresetName;
    double sourceBeamWaistPx = 0.0;

    QLabel *cameraFeedLabel;
    QLabel *cameraPixelLabel = nullptr;
    QComboBox *cameraPreviewMonitorCombo = nullptr;
    QPushButton *cameraPreviewToggleBtn = nullptr;
    QCheckBox *overlayTargetCb = nullptr;
    QComboBox *camSelect;
    QPushButton *camStartBtn;
    QPushButton *camStopBtn;
    QPushButton *captureImageBtn;
    QPushButton *recordVideoBtn;
    QLabel *recordTimeLabel;
    QTimer *recordTimeHideTimer = nullptr;

    // Backend Managers
    CameraManager *camManager;

    // Hardware Variables
    int slmWidth = 1920;
    int slmHeight = 1080;
    double slmPixelSize = 8.0;
    int cameraBackend = 0;
    int camWidth = 1920;
    int camHeight = 1080;
    double camPixelSize = 5.0;
    int cameraViewRotationDegrees = 0;
    bool flipCameraX = false;
    bool flipCameraY = false;
    bool saveCompressed = false;
    bool saveFollowsTransforms = false;
    QString udpBindIp = "0.0.0.0";
    int udpPort = 9000;
    double laserWavelength = 1064.0;
    double fourierFocalLength = 100.0;
    double cameraImagingMagnification = 1.0;
    bool isDarkMode = true;
    bool autoRunGsEnabled = false;
    bool autoSendSlmEnabled = false;
    int gsStartingPhaseMaskMode = 0;
    int gsComputeBackendMode = 0;
    int openClPlatformIndex = 0;
    int openClDeviceIndex = 0;
    int cudaDeviceIndex = 0;

    // SLM Pointers & State
    QPushButton *loadPhaseBtn;
    QPushButton *sendSlmBtn;
    QPushButton *clearSlmBtn;

    int slmWindowID = 0;
    QImage currentMask;
    QImage correctionMask;
    QLibrary slmLibrary;

    // SLM Output Routing State
    int slmOutputMode = DllOutputMode;
    int selectedMonitorNumber = 2;
    int cameraPreviewMonitorNumber = 1;
    int slmActiveWidth = 1272;
    int slmActiveHeight = 1024;
    int slmActiveOffsetX = 0;
    int slmActiveOffsetY = 0;
    QString correctionMaskPath;

    QMenu *monitorSelectionMenu = nullptr;
    QActionGroup *monitorActionGroup = nullptr;
    QWidget *directOutputWindow = nullptr;
    QLabel *directOutputLabel = nullptr;
    QWidget *cameraPreviewWindow = nullptr;
    QLabel *cameraPreviewWindowLabel = nullptr;
    QPushButton *cameraPreviewWindowSaveBtn = nullptr;
    QPushButton *cameraPreviewWindowRecordBtn = nullptr;
    QLabel *cameraPreviewWindowRecordTimeLabel = nullptr;
    QLabel *cameraPreviewWindowFpsLabel = nullptr;
    QLabel *cameraPreviewWindowPixelLabel = nullptr;
    int cameraPreviewWindowMonitorNumber = -1;

    // Auto-run timer
    QTimer *gsAutoRunTimer = nullptr;
    QTimer *animationTimer = nullptr;
    QVector<QVector<QPointF>> animationFramePoints;
    QVector<QImage> animationPrecomputedMasks;
    int animationCurrentFrameIndex = 0;
    int animationIterationsSnapshot = 20;
    bool animationSequenceReady = false;
    bool animationPrecomputeReady = false;
    bool animationRealtimeRunning = false;
    bool animationPlaybackRunning = false;
    bool animationComputeLimitedWarned = false;
    SequenceSource activeSequenceSource = SequenceSource::AnimationPreset;
    int selectedSequenceTrapIndexOneBased = -1;
    PythonTrapScriptEngine *pythonScriptEngine = nullptr;

    // Grid point data
    QMap<int, QPointF> gridPointData;
    int selectedPointId = -1;
    bool suppressGridStatusMessages = false;
    bool trapTableSyncInProgress = false;
    QString lastGeneratedPatternSummary;
    QString lastGeneratedPatternDetails;
    QImage lastCameraFrame;
    QImage lastRenderedCameraFrame;
    QImage lastOverlayRenderedCameraFrame;
    QImage lastZoomedRenderedCameraFrame;
    qint64 lastTargetCameraTabUpdateMs = 0;
    QRectF cameraZoomRoiNormalized = QRectF(0.0, 0.0, 1.0, 1.0);
    QVector<QRectF> cameraZoomHistory;
    bool cameraZoomEnabled = false;
    bool cameraZoomDragActive = false;
    QPoint cameraZoomDragStart;
    QPoint cameraZoomDragCurrent;
    bool cameraFeedActive = false;
    QUdpSocket *xpSenderOverlaySocket = nullptr;
};

#endif // MAINWINDOW_H
