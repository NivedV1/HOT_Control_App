#ifndef TARGETGRIDWIDGET_H
#define TARGETGRIDWIDGET_H

#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsItem>
#include <QVector>
#include <QPointF>
#include <QImage>

class QGraphicsPixmapItem;

class GridPoint : public QGraphicsItem {
public:
    GridPoint(QPointF pixelCoords, int pointId, QGraphicsItem *parent = nullptr);
    
    QRectF boundingRect() const override;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) override;
    
    QPointF getPixelCoordinates() const { return pixelCoordinates; }
    void setPixelCoordinates(QPointF coords) { pixelCoordinates = coords; }
    int getPointId() const { return pointId; }
    bool isSelected() const { return selected; }
    void setSelected(bool sel) { selected = sel; update(); }
    
protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event) override;
    
private:
    QPointF pixelCoordinates;  // Coordinates in pixels
    int pointId;
    bool selected;
    bool isDragging;
    static const double POINT_RADIUS;
};

class TargetGridWidget : public QGraphicsView {
    Q_OBJECT

public:
    enum class DisplayMode {
        GridOnly,
        StaticImage,
        LiveCamera
    };

    explicit TargetGridWidget(int cameraWidth = 1920, int cameraHeight = 1080, QWidget *parent = nullptr);
    ~TargetGridWidget();
    
    // Add/remove points
    void addPoint(QPointF pixelCoords);
    void addPoint(QPointF pixelCoords, int pointId);
    void removePoint(int pointId);
    void clearAllPoints();
    bool hasPoint(int pointId) const;
    bool selectPoint(int pointId);
    bool movePointById(int pointId, int deltaX, int deltaY);
    bool setPointCoordinates(int pointId, const QPointF &pixelCoords);
    
    // Get all points
    QVector<QPair<int, QPointF>> getAllPoints() const;
    
    // Grid settings
    void setGridResolution(int cameraWidth, int cameraHeight);
    QSize gridResolution() const { return QSize(cameraWidth, cameraHeight); }
    
    // Center the view
    void centerView();
    
    // Theme support
    void setDarkMode(bool dark);
    
    // Image mode support
    void setBackgroundImage(const QImage &imgGrayCameraSized);
    void clearBackgroundImage();
    void setDisplayMode(DisplayMode mode);
    DisplayMode displayMode() const { return currentDisplayMode; }
    QPointF sceneToPixel(QPointF scenePos) const;
    QPointF pixelToScene(QPointF pixelPos) const;
    
signals:
    void pointAdded(int pointId, QPointF pixelCoords);
    void pointMoved(int pointId, QPointF newPixelCoords);
    void pointRemoved(int pointId);
    void pointSelected(int pointId);
    void pointDeselected();

protected:
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;
    void keyPressEvent(QKeyEvent *event) override;
    void wheelEvent(QWheelEvent *event) override;
    void drawBackground(QPainter *painter, const QRectF &rect) override;
    void drawForeground(QPainter *painter, const QRectF &rect) override;
    void resizeEvent(QResizeEvent *event) override;
    void showEvent(QShowEvent *event) override;

private:
    void updateGridDisplay();
    void deselectAllPoints();
    QPointF screenToPixel(QPointF screenPos) const;
    QPointF pixelToScreen(QPointF pixelPos) const;
    void fitGridToView();
    bool isInteractiveDisplayMode() const;
    void drawGridOverlay(QPainter *painter, const QRectF &rect, bool hasImageBackground) const;
    void updateBackgroundPixmap();
    
    QGraphicsScene *gridScene;
    int cameraWidth;      // Camera resolution width in pixels
    int cameraHeight;     // Camera resolution height in pixels
    QVector<GridPoint*> gridPoints;
    int nextPointId;
    GridPoint *selectedPoint;
    bool pointDragActive = false;
    QPointF pointDragOffset;
    QGraphicsPixmapItem *imageItem;
    QImage backgroundImage;
    DisplayMode currentDisplayMode;
    
    // Theme colors
    bool isDarkMode;
    QColor bgColor;
    QColor minorGridColor;
    QColor majorGridColor;
    QColor axisColor;
    QColor centerPointColor;
    QColor borderColor;
    QColor textColor;
    bool fitGridInProgress = false;
    
    void updateThemeColors();
};

#endif // TARGETGRIDWIDGET_H
